
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `clientes`
--

DROP TABLE IF EXISTS `clientes`;
CREATE TABLE IF NOT EXISTS `clientes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) CHARACTER SET utf8 COLLATE utf8_spanish2_ci NOT NULL,
  `idTipoDoc` int(11) NOT NULL,
  `nroDoc` varchar(11) CHARACTER SET utf8 COLLATE utf8_spanish2_ci NOT NULL,
  `idGiroNegocio` int(11) NOT NULL,
  `direccion` text CHARACTER SET utf8 COLLATE utf8_spanish2_ci NOT NULL,
  `referencia` text CHARACTER SET utf8 COLLATE utf8_spanish2_ci NOT NULL,
  `ubigeoId` int(11) NOT NULL,
  `idSubagente` int(11) NOT NULL,
  `eliminar` tinyint(1) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
