
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `clientes_contactos`
--

DROP TABLE IF EXISTS `clientes_contactos`;
CREATE TABLE IF NOT EXISTS `clientes_contactos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `clienteId` int(11) NOT NULL,
  `nombre` varchar(255) NOT NULL,
  `telefono` varchar(255) NOT NULL,
  `celular` varchar(255) NOT NULL,
  `correo` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
