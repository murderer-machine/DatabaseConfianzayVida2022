
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `empresas_seguros`
--

DROP TABLE IF EXISTS `empresas_seguros`;
CREATE TABLE IF NOT EXISTS `empresas_seguros` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) NOT NULL,
  `ruc` varchar(255) NOT NULL,
  `factorGeneral` decimal(10,4) NOT NULL,
  `factorSoat` decimal(10,4) NOT NULL,
  `gastosEmision` decimal(10,4) NOT NULL,
  `gastosEmisionMinimo` decimal(10,4) NOT NULL,
  `gastosEmisionMinimoSoat` decimal(10,4) NOT NULL,
  `activo` tinyint(1) NOT NULL,
  `logo` varchar(255) NOT NULL,
  `eliminar` tinyint(1) NOT NULL,
  `createdAt` datetime DEFAULT NULL,
  `updatedAt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
