
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mensajes_whatsapps`
--

DROP TABLE IF EXISTS `mensajes_whatsapps`;
CREATE TABLE IF NOT EXISTS `mensajes_whatsapps` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `puntosVentaId` int(11) NOT NULL,
  `mensaje` text COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `mensajes_whatsapps`
--

INSERT INTO `mensajes_whatsapps` (`id`, `puntosVentaId`, `mensaje`) VALUES
(1, 2, 'X2'),
(2, 2, 'X 3'),
(3, 2, 'De tahuaycani hasta el óvalo si'),
(4, 2, 'Habla marquiño'),
(5, 2, 'Aquí en el work'),
(6, 2, 'Tu en q andas'),
(7, 2, 'Buenas tardes un soat'),
(8, 2, 'buenas tardes'),
(9, 2, 'enviar los datos'),
(10, 2, 'uso'),
(11, 2, '?'),
(12, 2, 'Positiva cuánto esta'),
(13, 2, 'Particular');
