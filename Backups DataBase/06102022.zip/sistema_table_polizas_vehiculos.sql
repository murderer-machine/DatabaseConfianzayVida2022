
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `polizas_vehiculos`
--

DROP TABLE IF EXISTS `polizas_vehiculos`;
CREATE TABLE IF NOT EXISTS `polizas_vehiculos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `polizaId` int(11) NOT NULL,
  `placa` varchar(255) NOT NULL,
  `clase` int(11) NOT NULL,
  `uso` int(11) NOT NULL,
  `categoria` int(11) NOT NULL,
  `marca` int(11) NOT NULL,
  `modelo` int(11) NOT NULL,
  `ano` int(11) NOT NULL,
  `nro_asientos` int(11) NOT NULL,
  `nro_pasajeros` int(11) NOT NULL,
  `nro_serie` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
