
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `puntos_ventas`
--

DROP TABLE IF EXISTS `puntos_ventas`;
CREATE TABLE IF NOT EXISTS `puntos_ventas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombres` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `apellidos` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `abreviatura` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `direccion` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `referencia` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `ubigeoId` int(11) NOT NULL,
  `comision` decimal(10,2) NOT NULL,
  `fecha_activacion` datetime NOT NULL,
  `usuarioId` int(11) NOT NULL,
  `observaciones` text COLLATE utf8_spanish_ci NOT NULL,
  `eliminar` tinyint(1) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `puntos_ventas`
--

INSERT INTO `puntos_ventas` (`id`, `nombres`, `apellidos`, `abreviatura`, `direccion`, `referencia`, `ubigeoId`, `comision`, `fecha_activacion`, `usuarioId`, `observaciones`, `eliminar`, `createdAt`, `updatedAt`) VALUES
(1, 'marco antonio', 'rodriguez salinas', 'quiñones', 'ovalo quiñones', 'cerca al ovalo', 10101, '15.00', '2022-09-09 11:30:12', 0, 'todo bien por favor recuerde mas cosas', 0, '2022-09-09 16:30:12', '2022-09-09 17:51:51'),
(2, 'pamela mary', 'suarez palomino', 'avelino', 'cercar al avelino', 'cerca a caja piura', 10101, '20.00', '2022-09-09 17:31:19', 0, 'pamela esta mal de la cabeza esta loca debe ojo pestaña y ceja', 0, '2022-09-09 17:31:19', '2022-09-09 17:51:53');
