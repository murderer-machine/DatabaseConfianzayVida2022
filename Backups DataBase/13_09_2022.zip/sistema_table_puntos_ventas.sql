
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `puntos_ventas`
--

DROP TABLE IF EXISTS `puntos_ventas`;
CREATE TABLE IF NOT EXISTS `puntos_ventas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombres` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `apellidos` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `abreviatura` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `direccion` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `referencia` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `ubigeoId` int(11) NOT NULL,
  `comision` decimal(10,2) NOT NULL,
  `fecha_activacion` datetime NOT NULL,
  `usuarioId` int(11) NOT NULL,
  `observaciones` text COLLATE utf8_spanish_ci NOT NULL,
  `eliminar` tinyint(1) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `puntos_ventas`
--

INSERT INTO `puntos_ventas` (`id`, `nombres`, `apellidos`, `abreviatura`, `direccion`, `referencia`, `ubigeoId`, `comision`, `fecha_activacion`, `usuarioId`, `observaciones`, `eliminar`, `createdAt`, `updatedAt`) VALUES
(1, 'marco antonio', 'rodriguez salinas', '12321321', 'jr grau nro 536 ', '13213', 10501, '10.50', '2022-09-13 05:00:00', 0, '3213213213212121', 0, '2022-09-13 20:55:09', '2022-09-13 20:55:09'),
(2, 'marco antonio', 'rodriguez salinas', '12321321', 'jr grau nro 536 ', '13213', 10501, '10.50', '2022-09-13 05:00:00', 0, '3213213213212121', 0, '2022-09-13 20:56:12', '2022-09-13 20:56:12'),
(3, 'marco antonio', 'rodriguez salinas', '12321321', 'jr grau nro 536 ', '13213', 10501, '10.50', '2022-09-13 05:00:00', 0, '3213213213212121', 0, '2022-09-13 20:56:16', '2022-09-13 20:56:16'),
(4, 'marco antonio', 'rodriguez salinas', '12321321', 'jr grau nro 536 ', '13213', 10501, '10.50', '2022-09-13 05:00:00', 0, '3213213213212121', 0, '2022-09-13 20:56:18', '2022-09-13 20:56:18'),
(5, 'marco antonio', 'rodriguez salinas', '12321321', 'jr grau nro 536 ', '13213', 10501, '10.50', '2022-09-13 05:00:00', 0, '3213213213212121', 0, '2022-09-13 20:56:19', '2022-09-13 20:56:19'),
(6, 'marco antonio', 'rodriguez salinas', '12321321', 'jr grau nro 536 ', '13213', 10501, '10.50', '2022-09-13 05:00:00', 0, '3213213213212121', 0, '2022-09-13 20:56:20', '2022-09-13 20:56:20'),
(7, 'marco antonio', 'rodriguez salinas', '12321321', 'jr grau nro 536 ', '13213', 10501, '10.50', '2022-09-13 05:00:00', 0, '3213213213212121', 0, '2022-09-13 21:05:04', '2022-09-13 21:05:04'),
(8, 'marco antonio', 'rodriguez salinas', '12321321', 'jr grau nro 536 ', '13213', 10501, '10.50', '2022-09-13 05:00:00', 0, '3213213213212121', 0, '2022-09-13 21:05:05', '2022-09-13 21:05:05'),
(9, 'marco antonio', 'rodriguez salinas', '12321321', 'jr grau nro 536 ', '13213', 10501, '10.50', '2022-09-13 05:00:00', 0, '3213213213212121', 0, '2022-09-13 21:05:06', '2022-09-13 21:05:06'),
(10, 'marco antonio', 'rodriguez salinas', '12321321', 'jr grau nro 536 ', '13213', 10501, '10.50', '2022-09-13 05:00:00', 0, '3213213213212121', 0, '2022-09-13 21:05:06', '2022-09-13 21:05:06'),
(11, 'marco antonio', 'rodriguez salinas', '12321321', 'jr grau nro 536 ', '13213', 10501, '10.50', '2022-09-13 05:00:00', 0, '3213213213212121', 0, '2022-09-13 21:05:07', '2022-09-13 21:05:07'),
(12, 'marco antonio', 'rodriguez salinas', '12321321', 'jr grau nro 536 ', '13213', 10501, '10.50', '2022-09-13 05:00:00', 0, '3213213213212121', 0, '2022-09-13 21:05:08', '2022-09-13 21:05:08'),
(13, 'marco antonio', 'rodriguez salinas', '12321321', 'jr grau nro 536 ', '13213', 10501, '10.50', '2022-09-13 05:00:00', 0, '3213213213212121', 0, '2022-09-13 21:05:09', '2022-09-13 21:05:09'),
(14, 'marco antonio', 'rodriguez salinas', '12321321', 'jr grau nro 536 ', '13213', 10501, '10.50', '2022-09-13 05:00:00', 0, '3213213213212121', 0, '2022-09-13 21:05:10', '2022-09-13 21:05:10'),
(15, 'marco antonio', 'rodriguez salinas', '12321321', 'jr grau nro 536 ', '13213', 10501, '10.50', '2022-09-13 05:00:00', 0, '3213213213212121', 0, '2022-09-13 21:05:18', '2022-09-13 21:05:18'),
(16, 'marco antonio', 'rodriguez salinas', '12321321', 'jr grau nro 536 ', '13213', 10501, '10.50', '2022-09-13 05:00:00', 0, '3213213213212121', 0, '2022-09-13 21:05:19', '2022-09-13 21:05:19'),
(17, 'marco antonio', 'rodriguez salinas', '12321321', 'jr grau nro 536 ', '13213', 10501, '10.50', '2022-09-13 05:00:00', 0, '3213213213212121', 0, '2022-09-13 21:05:20', '2022-09-13 21:05:20'),
(18, 'marco antonio', 'rodriguez salinas', '12321321', 'jr grau nro 536 ', '13213', 10501, '10.50', '2022-09-13 05:00:00', 0, '3213213213212121', 0, '2022-09-13 21:05:21', '2022-09-13 21:05:21'),
(19, 'marco antonio', 'rodriguez salinas', '12321321', 'jr grau nro 536 ', '13213', 10501, '10.50', '2022-09-13 05:00:00', 0, '3213213213212121', 0, '2022-09-13 21:05:31', '2022-09-13 21:05:31'),
(20, 'marco antonio', 'rodriguez salinas', '12321321', 'jr grau nro 536 ', '13213', 10501, '10.50', '2022-09-13 05:00:00', 0, '3213213213212121', 0, '2022-09-13 22:07:04', '2022-09-13 22:07:04'),
(21, 'dasdsadasdsa', '213213', '12321321', 'jr grau nro 536 ', '13213', 10500, '10.50', '2022-09-13 05:00:00', 0, '* nombres es requerido\n* nombres no puede estar vacio\n* nombres debe ser una cadena de texto\n* apellidos es requerido\n* apellidos no puede estar vacio\n* apellidos debe ser una cadena de texto\n* abreviatura es requerido\n* abreviatura no puede estar vacio\n* abreviatura debe ser una cadena de texto\n* direccion es requerido\n* direccion no puede estar vacio\n* direccion debe ser una cadena de texto\n* referencia es requerido\n* referencia no puede estar vacio\n* referencia debe ser una cadena de texto\n* ubigeo es requerido\n* ubigeo no puede estar vacio\n* comision es requerido\n* comision no puede estar vacio\n* comision debe ser un numero decimal\n* comision debe ser un numero decimal , con 2 decimales\n* observaciones es requerido\n* observaciones no puede estar vacio', 0, '2022-09-13 22:24:38', '2022-09-13 22:24:38');
