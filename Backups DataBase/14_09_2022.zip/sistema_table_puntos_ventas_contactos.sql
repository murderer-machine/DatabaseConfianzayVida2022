
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `puntos_ventas_contactos`
--

DROP TABLE IF EXISTS `puntos_ventas_contactos`;
CREATE TABLE IF NOT EXISTS `puntos_ventas_contactos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `puntosVentaId` int(11) NOT NULL,
  `nombres_apellidos` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `celular` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `correo` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `puntos_ventas_contactos`
--

INSERT INTO `puntos_ventas_contactos` (`id`, `puntosVentaId`, `nombres_apellidos`, `celular`, `correo`, `createdAt`, `updatedAt`) VALUES
(1, 1, 'asasd', 'asdas', 'dasdsad', '2022-09-14 22:54:24', '2022-09-14 22:54:24'),
(2, 12, 'sadasd', 'dasdsa', 'dsadsadsa', '2022-09-14 23:04:32', '2022-09-14 23:04:32'),
(3, 12, 'sadasd', 'dasdsa', 'dsadsadsa', '2022-09-14 23:04:34', '2022-09-14 23:04:34'),
(4, 12, 'sadasd', 'dasdsa', 'dsadsadsa', '2022-09-14 23:05:13', '2022-09-14 23:05:13');
