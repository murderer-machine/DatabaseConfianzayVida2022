
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `puntos_ventas_contactos`
--

DROP TABLE IF EXISTS `puntos_ventas_contactos`;
CREATE TABLE IF NOT EXISTS `puntos_ventas_contactos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `puntosVentaId` int(11) NOT NULL,
  `nombres_apellidos` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `celular` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `correo` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `puntos_ventas_contactos`
--

INSERT INTO `puntos_ventas_contactos` (`id`, `puntosVentaId`, `nombres_apellidos`, `celular`, `correo`, `createdAt`, `updatedAt`) VALUES
(1, 3, 'sadasd', '959304050', 'carlosvaldivia@confianzayvida.com', '2022-09-15 18:33:22', '2022-09-15 18:33:22'),
(2, 3, 'sadasd', '959304050', 'marcorodriguez2013@outlook.com', '2022-09-15 18:33:28', '2022-09-15 18:33:28'),
(3, 3, 'sadasd', '959304050', 'carlosvaldivia@confianzayvida.com', '2022-09-15 21:51:20', '2022-09-15 21:51:20'),
(4, 3, 'sadasd', '959304050', 'carlosvaldivia@confianzayvida.com', '2022-09-15 21:51:25', '2022-09-15 21:51:25'),
(5, 3, 'sadasd', '959304050', 'marcorodriguez2013@outlook.com', '2022-09-15 21:51:30', '2022-09-15 21:51:30'),
(6, 3, 'sadasd', '959304050', 'carlosvaldivia@confianzayvida.com', '2022-09-15 22:20:06', '2022-09-15 22:20:06'),
(7, 4, 'ewqewqewq', '959304050', '505050@hotmail.com', '2022-09-15 22:26:32', '2022-09-15 22:26:32'),
(8, 4, 'dsadsad', '959305060', 'marcorodriguez2013@outlook.com', '2022-09-15 22:30:03', '2022-09-15 22:30:03'),
(9, 4, 'sadasd', '959304050', 'carlosvaldivia@confianzayvida.com', '2022-09-15 22:46:56', '2022-09-15 22:46:56'),
(10, 4, 'sadasd', '959304050', 'carlosvaldivia@confianzayvida.com', '2022-09-15 22:59:17', '2022-09-15 22:59:17'),
(11, 5, 'sadasd', '959304050', 'carlosvaldivia@confianzayvida.com', '2022-09-15 23:01:52', '2022-09-15 23:01:52'),
(12, 5, 'sadasd', '959304050', 'carlosvaldivia@confianzayvida.com', '2022-09-15 23:01:55', '2022-09-15 23:01:55'),
(13, 5, 'sadasd', '959304050', 'carlosvaldivia@confianzayvida.com', '2022-09-15 23:01:59', '2022-09-15 23:01:59'),
(14, 5, 'sadasd', '959304050', 'carlosvaldivia@confianzayvida.com', '2022-09-15 23:02:13', '2022-09-15 23:02:13'),
(15, 6, '45465465465465', '959304050', 'carlosvaldivia@confianzayvida.com', '2022-09-15 23:02:40', '2022-09-15 23:02:40');
