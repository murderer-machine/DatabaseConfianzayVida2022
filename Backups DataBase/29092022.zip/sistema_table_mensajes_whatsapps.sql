
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mensajes_whatsapps`
--

DROP TABLE IF EXISTS `mensajes_whatsapps`;
CREATE TABLE IF NOT EXISTS `mensajes_whatsapps` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `puntosVentaId` int(11) NOT NULL,
  `mensaje` text COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `mensajes_whatsapps`
--

INSERT INTO `mensajes_whatsapps` (`id`, `puntosVentaId`, `mensaje`) VALUES
(1, 1, 'hola'),
(2, 2, 'pepito'),
(3, 2, '1ua0w4md4kl8nkbu07.jpeg'),
(4, 2, '1ua0w4md4kl8nkca8b.jpeg'),
(5, 2, '1ua0w4md4kl8nkgeuz.jpeg'),
(6, 2, '1ua0w4md4kl8nkgjw3.jpeg'),
(7, 2, '1ua0w4md4kl8nkgotu.jpeg'),
(8, 2, '1ua0w4md4kl8nkht87.jpeg'),
(9, 2, '1ua0w4md4kl8nkhxsh.jpeg'),
(10, 2, '1ua0w4md4kl8nn2mre.jpeg'),
(11, 2, 'Hola'),
(12, 2, 'Hola'),
(13, 2, 'Cómo estas'),
(14, 2, '555'),
(15, 2, 'Cómo estas'),
(16, 2, 'Yo bien y tu'),
(17, 2, 'Hola'),
(18, 2, 'Hola'),
(19, 2, '1ua0w4md8cl8nne82a.jpeg');
