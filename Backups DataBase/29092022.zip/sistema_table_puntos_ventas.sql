
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `puntos_ventas`
--

DROP TABLE IF EXISTS `puntos_ventas`;
CREATE TABLE IF NOT EXISTS `puntos_ventas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombres` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `apellidos` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `abreviatura` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `direccion` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `referencia` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `ubigeoId` int(11) NOT NULL,
  `comision` decimal(10,2) NOT NULL,
  `fecha_activacion` datetime NOT NULL,
  `usuarioId` int(11) NOT NULL,
  `observaciones` text COLLATE utf8_spanish_ci NOT NULL,
  `eliminar` tinyint(1) NOT NULL,
  `whatsappId` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `puntos_ventas`
--

INSERT INTO `puntos_ventas` (`id`, `nombres`, `apellidos`, `abreviatura`, `direccion`, `referencia`, `ubigeoId`, `comision`, `fecha_activacion`, `usuarioId`, `observaciones`, `eliminar`, `whatsappId`, `createdAt`, `updatedAt`) VALUES
(1, 'marco antonio', 'rodriguez salinas', 'número postpago confianza', 'urb bancarios g-3', '-', 40129, '50.00', '2022-09-29 05:00:00', 0, '-', 0, '51941211801@c.us', '2022-09-29 19:45:13', '2022-09-29 19:45:13');
