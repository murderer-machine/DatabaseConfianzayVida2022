
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `empresas_bancarias`
--

DROP TABLE IF EXISTS `empresas_bancarias`;
CREATE TABLE IF NOT EXISTS `empresas_bancarias` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) NOT NULL,
  `eliminar` tinyint(1) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
