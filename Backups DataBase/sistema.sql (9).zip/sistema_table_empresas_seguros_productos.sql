
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `empresas_seguros_productos`
--

DROP TABLE IF EXISTS `empresas_seguros_productos`;
CREATE TABLE IF NOT EXISTS `empresas_seguros_productos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) NOT NULL,
  `empresasSeguroId` int(11) NOT NULL,
  `ramoId` int(11) NOT NULL,
  `comision` decimal(10,2) NOT NULL,
  `eliminar` tinyint(1) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
