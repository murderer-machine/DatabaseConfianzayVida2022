
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `polizas`
--

DROP TABLE IF EXISTS `polizas`;
CREATE TABLE IF NOT EXISTS `polizas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nroPoliza` varchar(255) CHARACTER SET utf8 COLLATE utf8_spanish2_ci NOT NULL,
  `nroPolizaCorregido` varchar(255) CHARACTER SET utf8 COLLATE utf8_spanish2_ci NOT NULL,
  `clienteId` int(11) NOT NULL,
  `empresasSeguroId` int(11) NOT NULL,
  `empresasSegurosProductoId` int(11) NOT NULL,
  `ramoId` int(11) NOT NULL,
  `moneda` int(11) NOT NULL,
  `descripcion` varchar(255) CHARACTER SET utf8 COLLATE utf8_spanish2_ci NOT NULL,
  `endosoAfavor` int(11) NOT NULL,
  `anulada` tinyint(1) NOT NULL,
  `idUsuario` int(11) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idCliente` (`clienteId`,`empresasSeguroId`,`empresasSegurosProductoId`,`ramoId`,`idUsuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
