
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `polizas_cupones`
--

DROP TABLE IF EXISTS `polizas_cupones`;
CREATE TABLE IF NOT EXISTS `polizas_cupones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `polizaId` int(11) NOT NULL,
  `nroOrden` int(11) NOT NULL,
  `nroCuota` int(11) NOT NULL,
  `importe` decimal(10,2) NOT NULL,
  `fechaObligacion` date NOT NULL,
  `fechaLimite` date NOT NULL,
  `situacion` int(11) NOT NULL,
  `fechaPago` date DEFAULT NULL,
  `observaciones` text NOT NULL,
  `revisadoGeneral` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
