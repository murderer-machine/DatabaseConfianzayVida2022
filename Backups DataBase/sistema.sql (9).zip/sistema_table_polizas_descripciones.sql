
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `polizas_descripciones`
--

DROP TABLE IF EXISTS `polizas_descripciones`;
CREATE TABLE IF NOT EXISTS `polizas_descripciones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `polizaId` int(11) NOT NULL,
  `id_subagente` int(11) NOT NULL,
  `fecha_emision` date NOT NULL,
  `tipo_vigencia` int(11) NOT NULL,
  `fecha_vigencia_inicio` date NOT NULL,
  `fecha_vigencia_fin` date NOT NULL,
  `ejecutivo` int(11) NOT NULL,
  `id_garantia` int(11) NOT NULL,
  `id_cargo` int(11) NOT NULL,
  `pago_empresa` int(11) NOT NULL,
  `pago_sub_agente` int(11) NOT NULL,
  `prima_total` decimal(10,2) NOT NULL,
  `prima_comercial` decimal(10,2) NOT NULL,
  `prima_neta` decimal(10,2) NOT NULL,
  `comision` decimal(10,2) NOT NULL,
  `porcentaje` decimal(10,2) NOT NULL,
  `comision_subagente` decimal(10,2) NOT NULL,
  `tipo_documento_poliza` int(11) NOT NULL,
  `tipo_pago` int(11) NOT NULL,
  `cancelado` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
