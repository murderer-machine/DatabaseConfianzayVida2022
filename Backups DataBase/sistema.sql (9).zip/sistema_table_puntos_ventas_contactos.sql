
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `puntos_ventas_contactos`
--

DROP TABLE IF EXISTS `puntos_ventas_contactos`;
CREATE TABLE IF NOT EXISTS `puntos_ventas_contactos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `puntosVentaId` int(11) NOT NULL,
  `nombres_apellidos` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `celular` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `correo` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `eliminar` tinyint(1) NOT NULL,
  `usuarioId` int(11) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `puntos_ventas_contactos`
--

INSERT INTO `puntos_ventas_contactos` (`id`, `puntosVentaId`, `nombres_apellidos`, `celular`, `correo`, `eliminar`, `usuarioId`, `createdAt`, `updatedAt`) VALUES
(1, 1, 'sadasd', '959304050', 'carlosvaldivia@confianzayvida.com', 0, 0, '2022-10-07 16:31:46', '2022-10-07 16:31:46'),
(2, 1, 'sadasd', '959304050', 'marcorodriguez2013@outlook.com', 0, 0, '2022-10-07 16:37:09', '2022-10-07 16:37:09');
