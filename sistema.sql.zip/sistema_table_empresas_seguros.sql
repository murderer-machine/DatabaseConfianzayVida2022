
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `empresas_seguros`
--

DROP TABLE IF EXISTS `empresas_seguros`;
CREATE TABLE IF NOT EXISTS `empresas_seguros` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) NOT NULL,
  `ruc` varchar(255) NOT NULL,
  `factorGeneral` decimal(10,4) NOT NULL,
  `factorSoat` decimal(10,4) NOT NULL,
  `gastosEmision` decimal(10,4) NOT NULL,
  `gastosEmisionMinimo` decimal(10,4) NOT NULL,
  `gastosEmisionMinimoSoat` decimal(10,4) NOT NULL,
  `activo` tinyint(1) NOT NULL,
  `logo` varchar(255) NOT NULL,
  `eliminar` tinyint(1) NOT NULL,
  `createdAt` datetime DEFAULT NULL,
  `updatedAt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `empresas_seguros`
--

INSERT INTO `empresas_seguros` (`id`, `nombre`, `ruc`, `factorGeneral`, `factorSoat`, `gastosEmision`, `gastosEmisionMinimo`, `gastosEmisionMinimoSoat`, `activo`, `logo`, `eliminar`, `createdAt`, `updatedAt`) VALUES
(1, 'avla peru compañia de seguros s a (antes aval peru', '20600825187', '1.2154', '1.2154', '1.0300', '5.0000', '0.0000', 0, '', 0, '2022-08-22 11:00:08', '2022-08-22 11:00:08'),
(2, 'bnp paribas cardif s a compañia de seguros y rease', '20513328819', '1.2154', '1.2154', '1.0300', '5.0000', '0.0000', 0, '', 0, '2022-08-22 11:00:08', '2022-08-22 11:00:08'),
(3, 'chubb perú s.a. compañia de seguros y reaseguros', '20390625007', '1.2154', '1.2154', '1.0300', '5.0000', '0.0000', 0, '', 0, '2022-08-22 11:00:08', '2022-08-22 11:00:08'),
(4, 'coface seguro de credito peru s.a', '20600524233', '1.2154', '1.2154', '1.0300', '5.0000', '0.0000', 0, '', 0, '2022-08-22 11:00:08', '2022-08-22 11:00:08'),
(5, 'compañia de seguros de vida camara s a.', '20554477721', '1.2154', '1.2154', '1.0300', '5.0000', '0.0000', 0, '', 0, '2022-08-22 11:00:08', '2022-08-22 11:00:08'),
(6, 'crecer seguros s.a. compañia de seguros', '20600098633', '1.2154', '1.2154', '1.0300', '5.0000', '0.0000', 1, 'crecer.png', 0, '2022-08-22 11:00:08', '2022-08-22 11:00:08'),
(7, 'insur s a compañia de seguros', '20492497721', '1.2154', '1.2154', '1.0300', '5.0000', '0.0000', 0, '', 0, '2022-08-22 11:00:08', '2022-08-22 11:00:08'),
(8, 'interseguro compañia de seguros s a', '20382748566', '1.2154', '1.2154', '1.0300', '5.0000', '0.0000', 0, '', 0, '2022-08-22 11:00:08', '2022-08-22 11:00:08'),
(9, 'la positiva seguros y reaseguros s.a.a.', '20100210909', '1.2154', '1.2154', '1.0300', '5.0000', '0.0000', 1, 'positiva.svg', 0, '2022-08-22 11:00:08', '2022-08-22 11:00:08'),
(10, 'la positiva vida seguros y reaseguros', '20454073143', '1.2154', '1.2154', '1.0300', '5.0000', '0.0000', 1, 'positiva.svg', 0, '2022-08-22 11:00:08', '2022-08-22 11:00:08'),
(11, 'liberty seguros s a', '20601127602', '1.2154', '1.2154', '1.0300', '5.0000', '0.0000', 0, '', 0, '2022-08-22 11:00:08', '2022-08-22 11:00:08'),
(12, 'mapfre peru compañia de seguros y reaseguros s.a.', '20202380621', '1.2154', '1.2392', '1.0300', '5.0000', '0.0000', 1, 'mapfre.svg', 0, '2022-08-22 11:00:08', '2022-08-22 11:00:08'),
(13, 'mapfre peru vida compañia de seguros y reaseguros', '20418896915', '1.2154', '1.2392', '1.0300', '5.0000', '0.0000', 1, 'mapfre.svg', 0, '2022-08-22 11:00:08', '2022-08-22 11:00:08'),
(14, 'ohio national seguros de vida s.a.', '20554816526', '1.2154', '1.2154', '1.0300', '5.0000', '0.0000', 0, '', 0, '2022-08-22 11:00:08', '2022-08-22 11:00:08'),
(15, 'pacifico compañia de seguros y reaseguros', '20332970411', '1.2154', '1.2272', '1.0300', '5.0000', '0.0000', 1, 'pacifico.svg', 0, '2022-08-22 11:00:08', '2022-08-22 11:00:08'),
(16, 'protecta s.a. compañia de seguros', '20517207331', '1.2154', '1.2272', '1.0300', '5.0000', '0.0000', 1, 'protecta.png', 0, '2022-08-22 11:00:08', '2022-08-22 11:00:08'),
(17, 'qualitas compañia de seguros s.a.', '20553157014', '1.2154', '1.2154', '1.0300', '5.0000', '0.0000', 0, '', 0, '2022-08-22 11:00:08', '2022-08-22 11:00:08'),
(18, 'rigel peru s.a. compañia de seguros de vida', '20552322704', '1.2154', '1.2154', '1.0300', '5.0000', '0.0000', 0, '', 0, '2022-08-22 11:00:08', '2022-08-22 11:00:08'),
(19, 'rimac seguros y reaseguros', '20100041953', '1.2154', '1.2154', '1.0300', '5.0000', '0.0000', 1, 'rimac.svg', 0, '2022-08-22 11:00:08', '2022-08-22 11:00:08'),
(20, 'secrex compañia de seguros de credito y garantias', '', '1.2154', '1.2154', '1.0300', '5.0000', '0.0000', 0, '', 0, '2022-08-22 11:00:08', '2022-08-22 11:00:08');
